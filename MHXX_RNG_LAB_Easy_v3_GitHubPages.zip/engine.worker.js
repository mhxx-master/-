/** Native browser worker — faithful port of apmnnn/mhxx-rng (MIT). */
import {scanRange} from './rng.js';
let validated=false;
const post=(type,payload={})=>self.postMessage({type,...payload});
const REFERENCE_CASES=[
  ['斬味',5,'痛撃',4,3,1716],
  ['連撃',4,'痛撃',5,3,4723],
  ['溜短',6,'納刀',6,3,5401],
  ['貫強',3,'会心',5,3,7934],
  ['痛撃',6,'達人',10,3,296260],
  ['属攻',4,'火攻',12,2,310605],
];
function validateEngine(){
 if(validated)return;
 post('status',{state:'loading',detail:'元コードの公開済みフレームを検証しています…'});
 for(const [first,firstSp,second,secondSp,slots,frame] of REFERENCE_CASES){
  const rows=scanRange({first,firstSp,second,secondSp,slots,origin:'マカ',mode:'exact'},Math.max(0,frame-150),300);
  if(!rows.some(r=>r.frame===frame))throw Error(`参照値 ${frame}F との照合に失敗しました。検索は停止します。`);
 }
 validated=true;
 post('ready',{detail:`元解析の既知フレーム${REFERENCE_CASES.length}件と照合済み。外部ライブラリ不要で検索できます。`});
}
async function search(message){
 if(!validated)throw Error('検索エンジン未検証です');
 const count=message.count,start=message.start;
 if(!Number.isSafeInteger(count)||count<1||count>50000000||!Number.isSafeInteger(start)||start<0||start+count>Number.MAX_SAFE_INTEGER)throw Error('検索範囲が不正です');
 const chunk=100000;
 const frames=[];
 let searched=0, early=false;
 for(let done=0;done<count;done+=chunk){
  const len=Math.min(chunk,count-done);
  const hits=scanRange(message,start+done,len,1000);
  for(const row of hits)frames.push(row.frame);
  searched+=len;
  if(message.firstOnly && frames.length){early=true; post('progress',{done:Math.min(count,done+len),total:count,frames:frames.slice(0,100),count:frames.length});break;}
  post('progress',{done:done+len,total:count,frames:frames.slice(0,100),count:frames.length});
  // Yield to the browser after each chunk so progress can be rendered and the
  // Cancel button can terminate this worker without waiting for the whole scan.
  await new Promise(resolve=>setTimeout(resolve,0));
 }
 post('complete',{frames: message.firstOnly ? frames.slice(0,1):frames, searched, early});
}
self.onmessage=async e=>{
 try {
  if(e.data.type==='init')validateEngine();
  if(e.data.type==='search')await search(e.data);
 } catch(err) {
  post('error',{message:String(err?.message||err),stack:String(err?.stack||'')});
 }
};
