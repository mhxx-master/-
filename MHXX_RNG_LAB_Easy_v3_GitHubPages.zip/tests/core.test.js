import test from 'node:test';
import assert from 'node:assert/strict';
import {REFERENCE_CHARM_FRAMES, normalizeSkill, formatFrame, validateInput} from '../lib.js';
test('documented frames are preserved as reference fixtures',()=> {
  assert.equal(REFERENCE_CHARM_FRAMES.find(x=>x.first==='連撃')?.frame,4723);
  assert.equal(REFERENCE_CHARM_FRAMES.find(x=>x.first==='溜短')?.frame,5401);
});
test('30 fps conversion',()=>{
  assert.equal(formatFrame(4723),'2分 37秒 13F');
  assert.equal(formatFrame(5401),'3分 00秒 1F');
  assert.equal(formatFrame(30*86400+31),'1日 0分 01秒 1F');
});
test('skill aliases',()=>{
  assert.equal(normalizeSkill('属性攻撃'),'属攻');
  assert.equal(normalizeSkill('溜め短縮'),'溜短');
  assert.equal(normalizeSkill('風圧'),'風圧');
});
test('input validation',()=>{
  const v={first:'属攻',firstSp:7,second:'風圧',secondSp:6,slots:0,origin:'マカ',mode:'exact',start:0,count:1000000};
  assert.equal(validateInput(v),null);
  assert.match(validateInput({...v,slots:4}),/スロット/);
  assert.match(validateInput({...v,start:-1}),/検索範囲/);
});
