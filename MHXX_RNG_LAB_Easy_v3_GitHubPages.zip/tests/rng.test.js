import test from 'node:test';
import assert from 'node:assert/strict';
import {scanRange,createScanner,jumpState,SEED,VALID_FIRST,VALID_SECOND} from '../rng.js';
const exact=(a,b,c,d,slots)=>({first:a,firstSp:b,second:c,secondSp:d,slots,origin:'マカ',mode:'exact'});
test('tables contain all original blue-tier skill entries',()=>{
 assert.equal(VALID_FIRST.length,62);
 assert.equal(VALID_SECOND.length,94);
 assert.ok(VALID_FIRST.includes('属攻'));
 assert.ok(VALID_SECOND.includes('風圧'));
});
test('known public results match with original formulas',()=>{
 const fixtures=[
  [1716,'斬味',5,'痛撃',4,3],
  [4723,'連撃',4,'痛撃',5,3],
  [5401,'溜短',6,'納刀',6,3],
  [7934,'貫強',3,'会心',5,3],
  [296260,'痛撃',6,'達人',10,3],
  [310605,'属攻',4,'火攻',12,2],
  [1333720,'斬味',7,'会心',5,3]
 ];
 for(const [frame,...args] of fixtures){
  const actual=scanRange(exact(...args),Math.max(0,frame-120),240).map(x=>x.frame);
  assert.ok(actual.includes(frame),`Expected documented ${frame}F but got ${actual}`);
 }
});
test('jump-ahead equals sequential RNG state at nearby arbitrary positions',()=>{
 assert.deepEqual(jumpState(0),SEED);
 const first=scanRange(exact('連撃',4,'痛撃',5,3),0,6000).map(x=>x.frame);
 const second=scanRange(exact('連撃',4,'痛撃',5,3),4700,100).map(x=>x.frame);
 assert.ok(first.includes(4723));
 assert.deepEqual(second,[4723]);
 const scanner=createScanner(0);
 for(let i=0;i<10000;i++) scanner.step();
 assert.equal(scanner.position,10000);
});
test('requested charm has 5424F as its first result',()=>{
 const rows=scanRange(exact('属攻',7,'風圧',6,0),0,10000);
 assert.deepEqual(rows.map(r=>r.frame),[5424]);
 assert.deepEqual([rows[0].value1,rows[0].value2,rows[0].slots],[7,6,0]);
});
test('invalid skills do not silently fall back to a different skill',()=>{
 assert.throws(()=>scanRange(exact('未知のスキル',4,'風圧',6,0),0,100),/第1スキル/);
});
