/**
 * MHXX RNG LAB: faithful JavaScript port of the RNG and blue-charm tables in
 * apmnnn/mhxx-rng (MIT), notebook mhxx-rng.ipynb, revision
 * b882bae8412a0311c84e5c5363a344c85599cf40.
 * The formulas, skill ID tables, point bounds and slot thresholds are copied
 * from set_blue, set_ja, ascend, roll, getcharm, slot, parameter and jump.
 * Original: https://github.com/apmnnn/mhxx-rng
 * See NOTICE.md for the original copyright/license.
 */
export const SEED=[0x0194FD72,0x79E6C985,0x08DD9701,0x41CFCE91];
const POLYNOMIAL=0x100000201a8362f671442057eea368001n;
const PERIOD=(1n<<128n)-1n;
const S1=[
4,5,10,11,14,15,25,31,32,35,
36,37,38,39,40,41,42,44,45,47,
48,49,50,64,65,66,68,70,71,72,
73,76,77,78,79,80,81,82,83,84,
85,86,87,90,92,93,94,95,97,99,
100,101,106,107,108,109,114,115,116,122,
123,132];
const P1=[
[3,7],[5,10],[3,7],[3,7],[3,7],[5,10],[3,7],[3,7],[3,7],[3,7],
[3,7],[1,5],[2,6],[1,5],[1,5],[5,10],[5,10],[3,7],[2,6],[2,6],
[2,6],[2,6],[2,6],[1,5],[1,5],[1,5],[3,7],[2,6],[1,5],[2,6],
[2,6],[2,6],[2,6],[3,7],[3,7],[2,6],[2,6],[2,6],[1,5],[3,7],
[3,7],[5,10],[5,10],[2,6],[2,6],[1,5],[1,5],[1,5],[2,6],[2,6],
[2,6],[1,5],[2,6],[1,5],[3,7],[3,7],[3,7],[1,5],[3,7],[2,6],
[3,7],[3,7]];
const S2=[
4,5,17,18,25,26,27,28,29,30,
32,33,34,35,36,37,39,40,41,43,
44,45,47,48,49,50,64,65,66,68,
69,70,71,74,75,76,77,78,79,80,
81,82,83,84,85,86,87,88,89,90,
91,92,93,94,95,96,97,99,100,101,
105,106,107,108,109,114,115,116,119,122,
123,125,132,134,135,136,161,162,163,164,
165,166,167,168,169,170,171,172,173,174,
175,176,177,178];
const P2=[
[3,5],[5,7],[7,10],[5,13],[5,7],[5,13],[5,13],[5,13],[5,13],[5,13],
[5,7],[7,10],[3,5],[5,7],[5,7],[3,5],[5,5],[2,8],[5,7],[3,3],
[5,7],[5,7],[3,5],[3,5],[3,5],[3,5],[3,5],[3,5],[3,5],[5,7],
[7,10],[3,5],[1,3],[3,5],[3,3],[3,5],[3,5],[3,5],[3,5],[3,5],
[3,5],[3,5],[1,3],[3,5],[3,5],[7,10],[7,10],[5,10],[5,10],[3,5],
[5,10],[3,5],[1,3],[1,3],[1,3],[3,3],[3,5],[3,5],[3,5],[1,3],
[7,10],[3,5],[1,3],[5,7],[5,7],[7,10],[1,3],[3,5],[5,12],[3,5],
[5,7],[3,5],[7,10],[5,7],[3,5],[5,7],[3,3],[3,3],[3,3],[3,3],
[3,3],[3,3],[3,3],[3,3],[3,3],[3,3],[3,3],[3,3],[3,3],[3,3],
[3,3],[3,3],[3,3],[3,3]];
const SLOT=[
[100,100,100],[3,53,88],[5,55,89],[7,57,89],[13,58,89],
[16,60,90],[22,62,90],[30,66,90],[38,68,91],[50,72,91],
[55,75,92],[59,77,92],[64,81,94],[67,83,94],[71,86,96],
[74,88,96],[79,91,98],[82,92,98],[86,94,99],[90,96,99]];
const JA = `毒　 麻痺 睡眠 気絶 聴覚 風圧 耐震 だる 耐暑 耐寒
寒冷 炎熱 盗み 対防 狂撃 細菌 裂傷 攻撃 防御 体力
火耐 水耐 雷耐 氷耐 龍耐 属耐 火攻 水攻 雷攻 氷攻
龍攻 属攻 特攻 研師 匠　 斬味 剣術 研磨 鈍器 抜会
抜減 納刀 納研 刃鱗 装速 反動 精密 通強 貫強 散強
重強 通追 貫追 散追 榴追 拡追 毒追 麻追 睡追 強追
属追 接追 減追 爆追 速射 射法 装数 変則 弾節 達人
痛撃 連撃 特会 属会 会心 裏会 溜短 スタ 体術 気力
走行 回性 回距 泡沫 ガ性 ガ強 ＫＯ 減攻 笛　 砲術
重撃 爆弾 本気 闘魂 無傷 チャ 龍気 底力 逆境 逆上
窮地 根性 気配 采配 号令 乗り 跳躍 無心 我慢 ＳＰ
千里 観察 狩人 運搬 加護 英雄 回量 回速 効果 広域
腹減 食い 食事 節食 肉食 茸食 野草 調成 調数 高速
採取 ハチ 護石 気ま 運気 剥取 捕獲 ベル ココ ポッ
ユク 龍識 飛行 紅兜 大雪 矛砕 岩穿 紫毒 宝纏 白疾
隻眼 黒炎 金雷 荒鉤 燼滅 朧隠 鎧裂 天眼 青電 銀嶺
鏖魔 真紅 真大 真矛 真岩 真紫 真宝 真白 真隻 真黒
真金 真荒 真燼 真朧 真鎧 真天 真青 真銀 真鏖 北辰
斬術 食欲 職工 剛腕 祈願 裏稼 刀匠 射手 状態 怒　
回術 居合 頑強 剛撃 盾持 潔癖 増幅 護収 強欲 対鋼
対霞 対炎 胴倍 秘術 護強`.trim().split(/\s+/u);

export const VALID_FIRST = S1.map(id=>JA[id]);
export const VALID_SECOND = S2.map(id=>JA[id]);
export const VALID_SKILLS = [...new Set([...VALID_FIRST,...VALID_SECOND])];
export function getSkillIndex(text, kind=1){
 const id=JA.indexOf(text);
 return id<0 ? -1 : (kind===1 ? S1:S2).indexOf(id);
}
function bitlen(x){let n=0;while(x){x>>=1n;n++}return n}
function polyMod(p,m){const ml=bitlen(m);while(p){const d=bitlen(p)-ml;if(d<0)break;p^=m<<BigInt(d)}return p}
function polyMul(p,q){let result=0n;while(q>0n){if(q&1n)result^=p;p<<=1n;q>>=1n}return result}
function powMod(base,exp,mod){let result=1n;base=polyMod(base,mod);while(exp>0n){if(exp&1n)result=polyMod(polyMul(result,base),mod);base=polyMod(polyMul(base,base),mod);exp>>=1n;}return result}
function nextState(state){const [x,y,z,w]=state;const t=(x^(x<<15))>>>0;state[0]=y;state[1]=z;state[2]=w;state[3]=(w^(w>>>21)^t^(t>>>4))>>>0;}
export function jumpState(frame){
 if (!Number.isSafeInteger(frame) || frame < 0) throw new Error('開始フレームは0以上の整数');
 const state=SEED.slice();
 if(frame===0) return state;
 let poly=powMod(2n,BigInt(frame)%PERIOD,POLYNOMIAL);
 const acc=[0,0,0,0];
 while(poly>0n){if(poly&1n){for(let j=0;j<4;j++)acc[j]=(acc[j]^state[j])>>>0}poly>>=1n;nextState(state)}
 return acc;
}
export function createScanner(start=0){
 const st=jumpState(start);
 let x=st[0],y=st[1],z=st[2],w=st[3];
 let r0=0,r1=0,r2=0,r3=0,r4=0,r5=0,r6=0;
 let frame=start;
 function roll(){r0=r1;r1=r2;r2=r3;r3=r4;r4=r5;r5=r6;r6=w;const t=(x^(x<<15))>>>0;x=y;y=z;z=w;w=(w^(w>>>21)^t^(t>>>4))>>>0;frame++}
 for(let i=0;i<7;i++)roll();
 function step(){roll();return frame-7}
 function getCharm(origin){
  const id1=r0%S1.length,id2=r3%S2.length;
  const s1=P1[id1][1],s2=P2[id2][1];
  const c0=S1[id1],c1=r1%(s1-P1[id1][0]+1)+P1[id1][0];
  let c2=-1,c3=0,tmp2=0,q5=r3;
  if(r2%100>=15){
   c2=S2[id2];
   let q4;
   if(origin===1&&r4%2===0){q4=r5;q5=r6;tmp2=q4%(P2[id2][0]+1)-P2[id2][0]}
   else {if(origin===1){q4=r5;q5=r6;}else{q4=r4;q5=r5;}tmp2=q4%P2[id2][1]+1;}
   c3=tmp2;
   if(c0===c2 || tmp2<0)tmp2=0;
  }
  const fill=Math.floor(((c1*s2+tmp2*s1)*10)/(s1*s2));
  const bounds=SLOT[fill-1];
  if (!bounds) throw new Error('スロット表の範囲外: '+fill);
  const q=q5%100;
  const slots=q>=bounds[2]?3:q>=bounds[1]?2:q>=bounds[0]?1:0;
  return {skill1:JA[c0],value1:c1,skill2:c2<0?'':JA[c2],value2:c3,slots,fill};
 }
 return {step,getCharm,get position(){return frame-7;},get roll(){return [r0,r1,r2,r3,r4,r5,r6]}};
}
export function compileTarget(t){
 const id1=getSkillIndex(t.first,1),id2=getSkillIndex(t.second,2);
 if(id1<0)throw new Error('第1スキルが風化したお守りの第1スキル候補にありません: '+t.first);
 if(id2<0)throw new Error('第2スキルが風化したお守りの第2スキル候補にありません: '+t.second);
 return {...t,id1,id2};
}
export function scanRange(target,start,length,maxResults=2000){
 const q=compileTarget(target);const scanner=createScanner(start);const results=[];
 for(let i=0;i<length;i++){
  const frame=scanner.step(),roll=scanner.roll;
  if(roll[0]%S1.length!==q.id1 || roll[2]%100<15 || roll[3]%S2.length!==q.id2)continue;
  const c=scanner.getCharm(q.origin==='炭鉱'?1:0);
  if(c.value1 < q.firstSp || c.value2 < q.secondSp || c.slots<q.slots)continue;
  if(q.mode==='exact' && (c.value1!==q.firstSp || c.value2!==q.secondSp || c.slots!==q.slots))continue;
  results.push({frame,...c});
  if(results.length>=maxResults)break;
 }
 return results;
}
