import {getSkillIndex} from './rng.js';
/** Publication-backed reference fixtures. These are not computed search results. */
export const REFERENCE_CHARM_FRAMES = Object.freeze([
 {first:'斬味',firstSp:5,second:'痛撃',secondSp:4,slots:3,frame:1716},
 {first:'連撃',firstSp:4,second:'痛撃',secondSp:5,slots:3,frame:4723},
 {first:'溜短',firstSp:6,second:'納刀',secondSp:6,slots:3,frame:5401},
 {first:'貫強',firstSp:3,second:'会心',secondSp:5,slots:3,frame:7934},
 {first:'痛撃',firstSp:6,second:'達人',secondSp:10,slots:3,frame:296260}
]);
const SKILL_ALIASES = {
  '属性攻撃':'属攻', '属性攻撃強化':'属攻', '溜め短縮':'溜短',
  '会心強化':'会心', '斬れ味':'斬味', '斬れ味レベル':'匠', '納刀術':'納刀',
  '斬れ味レベル+1':'匠', '斬れ味レベル+2':'匠',
  '貫通弾強化':'貫強', '貫通矢強化':'貫強', '炎熱適応':'炎熱', '抜刀術【技】':'抜会', '抜刀術【力】':'抜減',
  '抜刀会心':'抜会', '抜刀減気':'抜減',
};
export function normalizeSkill(text) { const key=String(text||'').trim();return SKILL_ALIASES[key] || key; }
export function formatFrame(frame) {
  if(!Number.isSafeInteger(frame) || frame<0) throw new RangeError('フレームは非負の整数');
  const seconds=Math.floor(frame/30), f=frame%30;
  const d=Math.floor(seconds/86400),h=Math.floor(seconds%86400/3600),m=Math.floor(seconds%3600/60),s=seconds%60;
  return `${d?d+'日 ':''}${h?String(h)+'時間 ':''}${m}分 ${String(s).padStart(2,'0')}秒 ${f}F`;
}
export function validateInput(req) {
  if (!req.first) return '第1スキルを指定してください。';
  if (getSkillIndex(req.first,1)<0) return '第1スキルが風化したお守りのテーブルにありません。略称または正式名で入力してください。';
  if (getSkillIndex(req.second,2)<0) return '第2スキルが風化したお守りのテーブルにありません。略称または正式名で入力してください。';
  if (!Number.isInteger(req.firstSp) || req.firstSp < -20 || req.firstSp >30) return '第1スキル値は整数で指定してください。';
  if (req.second && (!Number.isInteger(req.secondSp) || req.secondSp < -20 || req.secondSp >30)) return '第2スキル値は整数で指定してください。';
  if (![0,1,2,3].includes(req.slots)) return 'スロットは0〜3で指定してください。';
  if (!['マカ','炭鉱'].includes(req.origin)) return '産地の選択が不正です。';
  if (!['exact','greater'].includes(req.mode)) return '一致条件が不正です。';
  if (!Number.isSafeInteger(req.start) || req.start<0 || !Number.isSafeInteger(req.count) || req.count<1 || req.count>50000000) return '検索範囲が不正です。';
  return null;
}
