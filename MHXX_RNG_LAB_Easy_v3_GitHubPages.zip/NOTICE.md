# 利用した公開解析

このプロジェクトは apmnnn 氏が MIT ライセンスで公開する
[MHXX乱数解析ツール mhxx-rng](https://github.com/apmnnn/mhxx-rng)
のXorshift128乱数式、スキル抽選表、スロット表とジャンプ多項式を JavaScript に移植しています。原作者の独立した解析に基づいています。

元コードは特定コミット `b882bae8412a0311c84e5c5363a344c85599cf40` に固定しており、
原作者の公開コードの計算式・テーブルを移植した JavaScript コード（`rng.js`）をこのZIPに含みます。

原作の MIT ライセンス全文:

```text
MIT License

Copyright (c) 2026 apmnnn

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

この配布物にはPyodideやNumbaは含まれず、外部Python依存はありません。
